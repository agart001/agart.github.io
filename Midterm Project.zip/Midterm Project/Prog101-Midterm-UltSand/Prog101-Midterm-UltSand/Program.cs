﻿using System;

namespace Prog101_Midterm_UltSand
{
    class Program
    {
        static void Main()
        {
            //Create Instance of Store
            Store store = new Store();

            //Start store title and game loop
            store.Title();
            
        }
    }
}
