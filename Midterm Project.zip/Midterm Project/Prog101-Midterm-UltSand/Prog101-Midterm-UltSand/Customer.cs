﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Prog101_Midterm_UltSand
{
    class Customer
    {
        //Patience Vars
        public static int min_pat = 35;
        public static int max_pat = 95;
        int pat = 0;

        //Total and Tip vars
        double total = 0;
        double tip = 0;

        //Order Array
        string[] cust_order = new string[8];
      
        //Constructor - takes total, patience, and order array inputs
        public Customer(double _total, int _pat, string[] _order)
        {
            total = Math.Round(_total,2);
            pat = _pat;
            cust_order = _order;
        }

        public double GetTotal()
        {
            return total;
        }

        public int GetPatience()
        {
            return pat;
        }

        public string[] GetOrder()
        {
            return cust_order;
        }

        public void SetOrder(string[] _order)
        {
            cust_order = _order;
        }

        //Generates tip based on correctness, patience, and total
        public double GetTip(double _per_correct)
        {
            double _pat = Convert.ToDouble(pat);
            tip = (((_pat * (_per_correct / 100)) / 100) * total);
            tip = Math.Round(tip, 2);
            return tip;
        }
        
    }
}
