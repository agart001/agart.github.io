﻿using System;
using System.Collections.Generic;


namespace Prog101_Midterm_UltSand
{
    class Store
    {
        #region Variables, Instances, and Arrays
        Random rand = new Random();

        Player player = new Player();

        List<Customer> customers = new List<Customer>();

        int cust_index = 0;

        int level = 1;

        double level_time = 0;
        double max_time = 25;
        double min_time = 5;


        #region Arrays
        string[,] ingredients = new string[,]
        {
            {"Base", "french", "wheat", "rye", "lettuce wrap", "tortilla"},

            {"Spread", "none", "mayo", "avocado", "vinaigrette", "ranch"},

            {"Topping #1", "none", "tomato", "pickle", "onion", "peppers"},

            {"Topping #2", "none", "tomato", "pickle", "onion", "peppers"},

            {"Topping #3", "none", "tomato", "pickle", "onion", "peppers"},

            {"Lettuce", "none", "romaine", "iceberg", "spinach", "arugula"},

            {"Meat", "ham", "salami", "turkey", "roast beef", "tuna"},

            {"Cheese", "none", "cheddar", "provolone", "pepper jack", "swiss"}
        };

        double[,] prices = new double[,]
        {
            {0, 1.5, 1.5, 1.5, 1.75, 1.75},

            {1, 0, .25, .75, .5, .5},

            {2, 0, .1, .15, .15, .2},

            {3, 0, .1, .15, .15, .2},

            {4, 0, .1, .15, .15, .2},

            {5, 0, .75, .75, 1, 1},

            {6, 1.5, 1.5, 1.75, 1.75, 2},

            {7, 0, 1.5, 1.5, 1.75, 1.75}
        };
        #endregion

        #endregion

        #region Customer Functions
        void GetRandCustomer()
        {
            //Create patience and total - patience ranges given in customer class
            int _pat = rand.Next(Customer.min_pat,Customer.max_pat);
            double _total = 0;

            //Create empty order string
            string[] array = new string[8];
            int len = array.Length;

            //Fill order string with random ingredients
            for (int i = 0; i < len; i++)
            {
                int r_num = rand.Next(1, 6);
                array[i] = ingredients[i, r_num];
                _total += prices[i, r_num];
            };

            //Contruct newly generated customer, add them to customer list and increase the customer index
            Customer customer = new Customer(_total, _pat, array);
            customers.Add(customer);
            cust_index++;
        }

        void PrintCustomerOrder()
        { 
            //Access Customer's information
            double total = customers[cust_index - 1].GetTotal();
            string[] array = customers[cust_index - 1].GetOrder();
            int len = array.Length;

            Console.WriteLine("Customer's Order");
            Console.WriteLine("------------------------");

            //Display Customers Order and Total
            for (int i = 0; i < len; i++)
            {
                Console.WriteLine(ingredients[i, 0] + ": " + array[i]);
            }
            Console.WriteLine("------------------------");
            Console.WriteLine("Total: $" + total);
            Console.WriteLine("------------------------");

            //Create new Alarm
            Alarm alarm = new Alarm();

            //Set Alarm
            Console.WriteLine("Timer:");
            alarm.SetTimer(level_time);

            //Maintains Program while timer counts
            while (alarm.count!=level_time)
            {
                Console.ReadKey();
            }
        }
        #endregion

        #region Player Functions
        void GetPlayerOrder()
        {
            Console.Clear();

            PrintIngredients();

            //Make empty order array to fill
            string[] array = new string[8];
            int len = array.Length;

            Console.WriteLine("------------------------");
            Console.WriteLine("Make the Order!");
            Console.WriteLine("------------------------");

            //Fill order array with player input
            for (int i = 0; i < len; i++)
            {
                Console.WriteLine("------------------------");
                Console.WriteLine(ingredients[i,0] + ": ");
                string input = Input.GetString();
                array[i] = input;
            }
            player.SetOrder(array);
        }

        void PrintPlayerOrder()
        {
            Console.Clear();

            //Access Player's Information
            string[] array = player.GetOrder();
            int len = array.Length;

            //Display Player's Information
            LevelHeader();

            Console.WriteLine("Player's Order");
            Console.WriteLine("------------------------");

            for (int i = 0; i < len; i++)
            {
                Console.WriteLine(ingredients[i, 0] + ": " + array[i]);
            }
            Console.WriteLine("------------------------");

           
        }
        #endregion

        #region Comparative Functions
        void CompareOrders(string[] p_order, string[] c_order)
        {
            //Compare the Player/Customer Orders
            double correct = 0;
            double len = 8;
            for (int i = 0; i < len; i++)
            {
                if(p_order[i].ToLower() == c_order[i].ToLower())
                {
                    correct++;
                }
            }

            //Determine correctness and tip
            double per_correct = (correct / len) * 100;
            double tip = customers[cust_index - 1].GetTip(per_correct);

            player.SetTips(tip);

            Console.WriteLine("Customer Tip: " + tip);
        }

        void CheckConditions()
        {
            double tips = player.GetTips();

            //Check Tips
            if (tips >= Player.tip_max)
            {
                Console.WriteLine("------------------------");
                Console.WriteLine("You hit the max tips for the day! Collect your tips!");
                Console.WriteLine("------------------------");
                Console.WriteLine("Total Tips: " + tips);
                Console.WriteLine("------------------------");
                Console.ReadKey();
            }
        }
        #endregion

        #region Level Functions
        void SetLevel()
        {
            //Increase level based on customer number - every 3 customers, the level increases
            if (cust_index != 0)
            { 
                if (cust_index % 3 == 0)
                {
                level++;
                }

            }

            //Check Win Conditions - Level is greater than 3 or player earned 10+ in tips
            CheckConditions();

            //Set timer duration based on level
            double d_level = Convert.ToDouble(level);
            double r_time = Math.Round((1 / d_level), 2);

            level_time = (max_time * r_time) + min_time;

            //Level Header
            LevelHeader();
        }

        void ResetLevel()
        {
            //Get Players input to restart game
            Console.WriteLine("------------------------");
            Console.WriteLine("Serve the Next Customer? (Y or N)");
            string input = Input.GetString();

            //Restart Game
            if (input.ToLower() == "y")
            {
                Console.Clear();
                Loop();
            }
            //End Game
            else if (input.ToLower() == "n")
            {
                Console.WriteLine("------------------------");
                Console.WriteLine("Press any Key");
                Console.WriteLine("------------------------");
                Console.ReadKey();
            }
            //Incorrect Input
            else 
            {
                Console.WriteLine("------------------------");
                Console.WriteLine("Incorrect Input");
                ResetLevel();
            }
        }

        void LevelHeader()
        {
            //Level Header
            double tips = player.GetTips();
            Console.WriteLine("------------------------");
            Console.WriteLine("Level: " + level + "   Tips: " + tips);
            Console.WriteLine("------------------------");
        }

        void PrintIngredients()
        {
            Console.WriteLine("------------------------------------------");
            Console.WriteLine("           Ingredient List");
            Console.WriteLine("------------------------------------------");

            //Set array length variables
            int len = 8;
            int a_len = 6;

            //loop through first array -  type
            for (int i = 0; i < len; i++)
            {
                Console.WriteLine("------------------------------------------");
                Console.WriteLine(ingredients[i, 0] + ": ");

                //loop through second array - specific ingredient
                for (int a = 1; a < a_len; a++)
                {
                    //print array elements in-line
                    string ing = ingredients[i, a];
                    Console.Write(ing + ", ");

                    //insert line break at the end of array
                    if (a == a_len - 1)
                    {
                        Console.Write("\r\n");
                    }
                }
            }

            Console.WriteLine("------------------------------------------");
            Console.WriteLine("");
        }
        #endregion

        #region Start Functions
        public void Title()
        {
            #region ASCII Ultimate
            string ult =
                @"
                 
 __ __  _     ______  ____  ___ ___   ____  ______    ___ 
|  |  || |   |      ||    ||   |   | /    ||      |  /  _]
|  |  || |   |      | |  | | _   _ ||  o  ||      | /  [_ 
|  |  || |___|_|  |_| |  | |  \_/  ||     ||_|  |_||    _]
|  :  ||     | |  |   |  | |   |   ||  _  |  |  |  |   [_ 
|     ||     | |  |   |  | |   |   ||  |  |  |  |  |     |
 \__,_||_____| |__|  |____||___|___||__|__|  |__|  |_____|
                                                          

                 ";
            #endregion

            #region ASCII Sandwich
            string sand =
                @"
                 
  _____  ____  ____   ___    __    __  ____   __  __ __ 
 / ___/ /    ||    \ |   \  |  |__|  ||    | /  ]|  |  |
(   \_ |  o  ||  _  ||    \ |  |  |  | |  | /  / |  |  |
 \__  ||     ||  |  ||  D  ||  |  |  | |  |/  /  |  _  |
 /  \ ||  _  ||  |  ||     ||  `  '  | |  /   \_ |  |  |
 \    ||  |  ||  |  ||     | \      /  |  \     ||  |  |
  \___||__|__||__|__||_____|  \_/\_/  |____\____||__|__|
                                                        

                 ";
            #endregion

            #region ASCII Shop
            string shop =
                @"
                 
  _____ __ __   ___   ____  
 / ___/|  |  | /   \ |    \ 
(   \_ |  |  ||     ||  o  )
 \__  ||  _  ||  O  ||   _/ 
 /  \ ||  |  ||     ||  |   
 \    ||  |  ||     ||  |   
  \___||__|__| \___/ |__|   
                            

                 ";
            #endregion


            Console.WriteLine(ult);
            Console.WriteLine(sand);
            Console.WriteLine(shop);

            StartGame();
        }

        void StartGame()
        {
            Console.WriteLine("------------------------");
            Console.WriteLine("Play? Y or N");
        
            string input = Input.GetString();

            //Start Game
            if (input.ToLower() == "y")
            {
                Console.Clear();
                Loop();
            }
            //Exit Game
            else if (input.ToLower() == "n")
            {
                Console.WriteLine("------------------------");
                Console.WriteLine("Press any Key");
                Console.WriteLine("------------------------");
                Console.ReadKey();
            }
            //Incorrect Input
            else
            {
                Console.WriteLine("------------------------");
                Console.WriteLine("Incorrect Input");
                StartGame();
            }
        }
        #endregion

        public void Loop()
        {
            //Set level and level specific vars, check win conditions
            SetLevel();

            //Create Random Customer
            GetRandCustomer();

            //Display Customers Order
            PrintCustomerOrder();

            //Get Players created Order
            GetPlayerOrder();

            //Display Players Order
            PrintPlayerOrder();

            //Compare Customer/Player Order for accuracy and decide the Player's tip
            CompareOrders(player.GetOrder(), customers[cust_index - 1].GetOrder());

            //Restart Loop
            ResetLevel();
        }
    }
}
