﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Prog101_Midterm_UltSand
{
    public static class Input
    {
        //Get string input
        public static string GetString()
        {
            //take input
            string input = Console.ReadLine();
            bool num_found = false;

            //search string input for digits
            foreach(char c in input)
            {
                if(Char.IsDigit(c))
                {
                    num_found = true;
                }
            }

            //Return input or restart loop based on string contents
            if(num_found)
            {
                Console.WriteLine("------------------------");
                Console.WriteLine("{ERROR} Digit found in String Input - Re-enter String Input");
                Console.WriteLine("------------------------");
                return GetString();
            }
            else { return input; }
        }
    }
}
