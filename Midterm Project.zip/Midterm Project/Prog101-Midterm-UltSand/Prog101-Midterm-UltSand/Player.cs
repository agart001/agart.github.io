﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Prog101_Midterm_UltSand
{
    class Player
    {
        //Tip Vars
        public static double tip_max = 15;
        double tips = 0;

        //Order Array
        string[] play_order = new string[8];

        public Player()
        {

        }

        //Sets Tip total
        public void SetTips(double _tip)
        {
            tips += _tip;
        }

        public double GetTips()
        {
            return tips;
        }

        public string[] GetOrder()
        {
            return play_order;
        }

        public void SetOrder(string [] _array)
        {
            play_order = _array;
        }
    }
}
