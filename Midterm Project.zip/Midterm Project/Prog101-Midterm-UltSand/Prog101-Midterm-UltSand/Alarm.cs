﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Timers;

namespace Prog101_Midterm_UltSand
{
    class Alarm
    {
        //Timer and Timer Vars
        Timer time = new Timer(1000);
        int time_count = 0;
        public int count = 0;

        //Set Timer
        public void SetTimer(double _time)
        {
            time_count = Convert.ToInt32(_time);

            time.Elapsed += Time_Elapsed;

            time.Start();
        }

        //Elapsed Event - counts, prints count, and stops timer 
        private void Time_Elapsed(object sender, ElapsedEventArgs e)
        {
            count++;

            Console.Write("\r" + new string(' ', Console.WindowWidth) + "\r");
            Console.Write(count);

            if (count==time_count)
            {
                Console.Clear();
                
                time.Stop();

                Console.WriteLine("------------------------");
                Console.WriteLine("Press any key");
                Console.WriteLine("------------------------");
            }
        }
    }
}
