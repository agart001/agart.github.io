﻿using System;
using static System.Console;

namespace ProgWeek2_HW_TipCalc
{
    class Program
    {
        static void Main()
        {
            float cost;
            float total;
            int tip;
            float tip_value;

            Console.WriteLine("What is the cost of the expense?(must provide a float)");
            cost = float.Parse(ReadLine());

            Console.WriteLine("What is the percentage of the tip?(must provide a int)");
            tip = int.Parse(Console.ReadLine());

            tip_value = cost * (tip / 100);
            total = tip_value + cost;

            Console.WriteLine("The value of the tip is {0}", tip_value);
            Console.WriteLine("The total cost is {0}", total);


        }
    }

    class TipCalc
    {
    }
}
