﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Prog101_Week5_TriviaGame
{
    class Player
    {
        int PlayerChoice = 0;
        int PlayerScore = 0;
        int PlayerFails = 0;

        public int SetPlayerScore()
        {
            PlayerScore++;
            return PlayerScore;
        }

        public int SetPlayerFails()
        {
            PlayerFails++;
            return PlayerFails;
        }

        public int GetPlayerChoice()
        {
            Console.WriteLine("Please enter your choice, use an integer to select: ");
            Console.WriteLine("-------------");
            PlayerChoice = GetIntInput();
            return PlayerChoice;
        }

        int GetIntInput()
        {
            string input = Console.ReadLine();

            if (int.TryParse(input, out int i_input))
            {
                return i_input;
            }
            else
            {
                Console.WriteLine("-------------");
                Console.WriteLine("Try Again!");
                Console.WriteLine("-------------");
                return PlayerChoice = GetPlayerChoice();
            }
        }
    }
}
