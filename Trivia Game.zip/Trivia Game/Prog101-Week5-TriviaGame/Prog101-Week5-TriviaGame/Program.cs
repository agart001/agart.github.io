﻿using System;

namespace Prog101_Week5_TriviaGame
{
    class Program
    {
        static void Main()
        {
            Game TriviaGame = new Game();

            TriviaGame.Start();
        }
    }
}
