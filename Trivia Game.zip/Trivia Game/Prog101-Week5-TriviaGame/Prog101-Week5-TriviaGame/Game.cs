﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Prog101_Week5_TriviaGame
{
    class Game
    {

        int TriviaChoice = 0;

        int WinCondition = 4;
        int FailCondition = 2;

        bool won = false;
        bool fail = false;
        bool repeat = false;

        int PlayerChoice = 0;
        int PlayerScore = 0;
        int PlayerFails = 0;

        Random rand = new Random();

        Player player = new Player();

        string[] TriviaQuestions = new string[]
        {
            "What color is the sky?",
            "What month is Halloween?",
            "The capital of Illinois is?",
            "Who is the current President of the US?",
            "When did COVID hit?",
            "Which gaming platform is the best?"
        };

        string[] TriviaAns1 = new string[]
        {
            "Red",
            "October",
            "Chicago",
            "Joe Biden",
            "2022",
            "Console"
        };

        string[] TriviaAns2 = new string[]
        {
            "Blue",
            "December",
            "Brookfield",
            "Elon Musk",
            "2020",
            "Mobile"
        };

        string[] TriviaAns3 = new string[]
        {
            "Green",
            "July",
            "Springfield",
            "Donald Trump",
            "2021",
            "PC"
        };

        int[] TriviaAnswer = new int[]
        {
            2,
            1,
            3,
            1,
            2,
            3
        };

        List<int> PrevTrivia = new List<int>();

        public void Start()
        {
            PrintTitle();
            GameLoop();
        }

        void GameLoop()
        {
            GetRandTriviaChoice();

            //didnt finish the question check

            //CheckTriviaRepeat(TriviaChoice);

            PrintTrivia(TriviaChoice);

            PlayerChoice = player.GetPlayerChoice();

            CheckAnswer(PlayerChoice, TriviaChoice);

            CheckConditions(PlayerScore, PlayerFails);

            RestartLoop(won, fail);
        }

        void PrintTitle()
        {
            Console.WriteLine("-------------");
            Console.WriteLine("WELCOME TO TRIVIA JANK");
            Console.WriteLine("-------------");
            Console.WriteLine("WIN CONDITION: 4 Right Answers");
            Console.WriteLine("LOSS CONDITION: 2 Wrong Answers");
        }

        void PrintTrivia(int triviachoice)
        {
            Console.WriteLine("-------------");
            Console.WriteLine("QUESTION");
            Console.WriteLine("-------------");
            Console.WriteLine(TriviaQuestions[triviachoice]);
            Console.WriteLine("-------------");
            Console.WriteLine("ANSWERS");
            Console.WriteLine("-------------");
            Console.WriteLine("1. " + TriviaAns1[triviachoice] + "\r\n");
            Console.WriteLine("2. " + TriviaAns2[triviachoice] + "\r\n");
            Console.WriteLine("3. " + TriviaAns3[triviachoice] + "\r\n");
            Console.WriteLine("-------------");
        }

        void GetRandTriviaChoice()
        {
            int rand_num = rand.Next(0, TriviaQuestions.Length);

            TriviaChoice = rand_num;
        }

        void CheckTriviaRepeat(int triviachoice)
        {

            foreach (var i in PrevTrivia)
            {
                if (i == triviachoice)
                {
                    Console.WriteLine("Repeat");
                    repeat = true;
                    break;
                }
            }

            if (repeat == true)
            {
                Console.WriteLine("Restart");
                GetRandTriviaChoice();
            }
            else
            {
                PrevTrivia.Add(triviachoice);
            }

        }

        void CheckAnswer(int playerchoice, int triviachoice)
        {
            if (playerchoice==TriviaAnswer[triviachoice])
            {
                Console.WriteLine("-------------");
                Console.WriteLine("You are Right!");
                PlayerScore = player.SetPlayerScore();
            }
            else
            {
                Console.WriteLine("-------------");
                Console.WriteLine("You are Wrong!");
                PlayerFails = player.SetPlayerFails();
            }
        }

        void CheckConditions(int playerscore, int playerfails)
        {
            CheckWin(playerscore);
            CheckFail(playerfails);
        }

        void CheckWin(int playerscore)
        {
            if(playerscore==WinCondition)
            {
                Console.WriteLine("-------------");
                Console.WriteLine("You Won!");
                won = true;
            }
        }

        void CheckFail(int playerfails)
        {
            if(playerfails==FailCondition)
            {
                Console.WriteLine("-------------");
                Console.WriteLine("You Failed!");
                fail = true;
            }

        }

        void RestartLoop(bool won, bool fail)
        {
            if(won==false&&fail==false)
            {
                Console.WriteLine("-------------");
                Console.WriteLine("Want to Play Again? enter 'Y' or 'N'");
                Console.WriteLine("-------------");
                GetRestartInput();
            }
            else
            {
                Console.WriteLine("-------------");
                Console.WriteLine("Press Any Key to Exit");
                Console.ReadKey();
            }
        }

        void GetRestartInput()
        {
            string input = Console.ReadLine();
            switch (input.ToLower())
            {
                case "y":
                    GameLoop();
                    break;
                case "n":
                    Console.WriteLine("-------------");
                    Console.WriteLine("Press Any Key to Exit");
                    Console.ReadKey();
                    break;
                default:
                    Console.WriteLine("-------------");
                    Console.WriteLine("Incorrect! Type 'y' or 'n'");
                    Console.WriteLine("-------------");
                    GetRestartInput();
                    break;
            }
        }
    }
}
